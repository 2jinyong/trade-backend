package com.jinyong.trade.dto;

import lombok.Data;

@Data
public class LoginDto {
    private String userId;
    private String password;
}
